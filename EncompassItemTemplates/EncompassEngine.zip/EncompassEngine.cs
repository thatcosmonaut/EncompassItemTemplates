﻿using Encompass;

namespace $rootnamespace$
{
    public class $safeitemname$ : Engine
    {
        public override void Update(double dt)
        {
            throw new System.NotImplementedException();
        }
    }
}
