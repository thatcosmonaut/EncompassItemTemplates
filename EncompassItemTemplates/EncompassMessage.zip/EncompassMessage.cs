﻿using Encompass;

namespace $rootnamespace$
{
    public struct $safeitemname$ : IMessage
    {
    }
}
